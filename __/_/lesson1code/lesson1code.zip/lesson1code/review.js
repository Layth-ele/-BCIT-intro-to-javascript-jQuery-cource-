document.getElementById('x').style.backgroundColor="yellow";

document.images[0].style.border="red dashed 2px";